# 💰 Ekonomicoachen

En snygg, AI-driven hemsida som hjälper dig att förbättra din ekonomi. Ange din inkomst, ditt sparmål och dina utgifter – och få personliga råd genererade av Claude AI.

## ✦ Funktioner

- **Inkomstregistrering** – Lön, CSN och övriga inkomster
- **Sparmål** – Slider för att ange hur mycket du vill spara per månad
- **Utgiftshantering** – Lägg till, redigera och ta bort utgiftskategorier
- **Budgetöversikt** – Visuell sammanfattning med inkomst, utgifter och överskott
- **AI-analys** – Personliga ekonomiråd via Claude AI (Anthropic)
- **Responsiv design** – Fungerar på mobil och desktop

## 🚀 Kom igång

### Kör lokalt

```bash
git clone https://github.com/DITT-ANVÄNDARNAMN/ekonomicoachen.git
cd ekonomicoachen
# Öppna index.html i din webbläsare
open index.html
```

> Ingen server eller installation krävs – det är en ren HTML/CSS/JS-fil!

### Publicera på GitHub Pages

1. Skapa ett nytt GitHub-repo
2. Ladda upp `index.html`
3. Gå till **Settings → Pages**
4. Välj **Deploy from branch → main → / (root)**
5. Din sida är live på `https://DITT-ANVÄNDARNAMN.github.io/REPO-NAMN`

## 🤖 AI-integration

Hemsidan använder Anthropics Claude API för att generera personliga ekonomiråd. API-nyckeln hanteras automatiskt via claude.ai när du kör appen där.

Om du hostar sidan externt behöver du lägga till din egen API-nyckel i `fetch`-anropet.

## 🎨 Design

- Mörkt tema med grain-overlay
- Typsnitt: Playfair Display + DM Mono + DM Sans
- Accent: Limegrön `#c8f060`
- Animerade inladdningseffekter och scroll-triggers

## 📄 Licens

MIT – Använd fritt!
